function Cost = Costfunction2(Np, Tim_step, X0, u, Vehicle_Type, Q, Xdes, R, F, Xa, G, Xnba)
% Cost function

    Pp = zeros(Np,1);     % Ԥ��λ��
    Vp = zeros(Np,1);     % Ԥ�⳵��
    Tp = zeros(Np,1);     % Ԥ���������ƶ�ת��
   
    Mass = Vehicle_Type(1);Radius = Vehicle_Type(2); g = Vehicle_Type(3);f = Vehicle_Type(4);
    Eta = Vehicle_Type(5);Ca = Vehicle_Type(6);Tao = Vehicle_Type(7);
    
    W = 10; 
%     motor x:ת�٣�y:ת�أ�f������Ч��
    p00 =       69.29;
    p10 =     0.05316 ;
    p01 =      0.1498  ;
    p20 =  -0.0001901;
    p11 =    0.001007 ;
    p02 =  -0.0008462 ;
    p30 =   1.685e-07 ;
    p21 =  -3.605e-06 ;
    p12 =  -2.205e-06 ;
    p03 =   2.058e-06 ;
    p40 =   1.765e-10 ;
    p31 =     5.8e-09  ;
    p22 =   4.794e-09 ;
    p13 =    2.27e-09  ;
    p04 =  -2.348e-09 ;
    p50 =   -2.58e-13;
    p41 =  -3.404e-12  ;
    p32 =  -3.623e-12 ;
    p23 =  -2.305e-12 ;
    p14 =  -7.636e-13  ;
    p05 =   9.897e-13  ;
       
    x = X0(2)/0.376*6.15;%  ����/���ְ뾶*���ٱ�
    y = abs(X0(3))/6.15; %  ת��/���ٱ�
    v = (p00 + p10*x + p01*y + p20*x^2 + p11*x*y + p02*y^2 + p30*x^3 + p21*x^2*y + ...
            p12*x*y^2 + p03*y^3 + p40*x^4 + p31*x^3*y + p22*x^2*y^2  +...
            p13*x*y^3 + p04*y^4 + p50*x^5 + p41*x^4*y + p32*x^3*y^2 + ...
            p23*x^2*y^3 + p14*x*y^4 + p05*y^5)/100;

    if X0(3) > 0
        P = (x*y)/(0.376*v);
    else
        P = (x*y)/(0.376)*v;
    end

    [Pp(1),Vp(1),Tp(1)] = VehicleDynamic(u(1),Tim_step,X0(1),X0(2),X0(3),Mass,Radius,g,f,Eta,Ca,Tao);
    for i = 1:Np-1 % ���� - 1
        [Pp(i+1),Vp(i+1),Tp(i+1)] = VehicleDynamic(u(i+1),Tim_step,Pp(i),Vp(i),Tp(i),Mass,Radius,g,f,Eta,Ca,Tao);
    end
    
    Xp = [Pp,Vp];         % Ԥ��״̬
    
    Udes = Radius/Eta*(Ca*Vp.^2 + Mass*g*f);
    U0 = Radius/Eta*(Ca*X0(2).^2 + Mass*g*f);
    
    Cost = (X0(1:2)-Xdes(1,:))*Q*(X0(1:2)-Xdes(1,:))' + ...
                (u(1)-U0)*R*(u(1)-U0) + (X0(1:2)-Xa(1,:))*F*(X0(1:2)-Xa(1,:))'+ ...
                (X0(1:2)-Xnba(1,:))*G*(X0(1:2)-Xnba(1,:))' + P*W*P  ;  % ��һ�����Ż�ֵ
    for i = 1:Np-1        %% ע�ⷶ���Ķ������⣬ X'Q'QX
        Cost = Cost + (Xp(i,:)-Xdes(i+1,:))*Q*(Xp(i,:)-Xdes(i+1,:))' + ...
                (u(i+1)-Udes(i))*R*(u(i+1)-Udes(i)) + (Xp(i,:)-Xa(i+1,:))*F*(Xp(i,:)-Xa(i+1,:))'+ ...
                (Xp(i,:)-Xnba(i+1,:))*G*(Xp(i,:)-Xnba(i+1,:))' + P*W*P ;               
    end
   
end

