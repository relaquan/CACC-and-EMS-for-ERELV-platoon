function Cost = Costfunction1(Np, Tim_step, X0, u, Vehicle_Type, Q, Xdes, R, F, Xa, G, Xnfa,Xnffa)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

    Pp = zeros(Np,1);     % Predictive Position
    Vp = zeros(Np,1);     % Predictive Velocity
    Tp = zeros(Np,1);     % Predictive Torque
    
    Mass = Vehicle_Type(1);
    Radius = Vehicle_Type(2); 
    g = Vehicle_Type(3);
    f = Vehicle_Type(4);
    Eta = Vehicle_Type(5);
    Ca = Vehicle_Type(6);
    Tao = Vehicle_Type(7);
    W = 10; 
     % motor x:ת�٣�y:ת�أ�f������Ч��
    p00 =       69.29;  
    p10 =    0.005566; 
    p01 =      0.1498;
    p20 =  -2.084e-06;  
    p11 =   0.0001054; 
    p02 =  -0.0008462; 
    p30 =   1.935e-10;  
    p21 =  -3.952e-08;  
    p12 =  -2.309e-07;  
    p03 =   2.058e-06;  
    p40 =   2.121e-14;  
    p31 =   6.656e-12;  
    p22 =   5.255e-11;  
    p13 =   2.377e-10; 
    p04 =  -2.348e-09;  
    p50 =  -3.246e-18;  
    p41 =   -4.09e-16;  
    p32 =  -4.158e-15;  
    p23 =  -2.526e-14;  
    p14 =  -7.995e-14;  
    p05 =   9.897e-13;  
    x = X0(2)/0.368;
    y = abs(X0(3));
    v = (p00 + p10*x + p01*y + p20*x^2 + p11*x*y + p02*y^2 + p30*x^3 + p21*x^2*y + ...
             p12*x*y^2 + p03*y^3 + p40*x^4 + p31*x^3*y + p22*x^2*y^2 +...
             p13*x*y^3 + p04*y^4 + p50*x^5 + p41*x^4*y + p32*x^3*y^2 +...
             p23*x^2*y^3 + p14*x*y^4 + p05*y^5)/100;
    
    [Pp(1),Vp(1),Tp(1)] = VehicleDynamic(u(1),Tim_step,X0(1),X0(2),X0(3),Mass,Radius,g,f,Eta,Ca,Tao);
    for i = 1:Np-1
        [Pp(i+1),Vp(i+1),Tp(i+1)] = VehicleDynamic(u(i+1),Tim_step,Pp(i),Vp(i),Tp(i),Mass,Radius,g,f,Eta,Ca,Tao);
    end
    
    Xp = [Pp,Vp];      % Predictive State
    
    Udes = Radius/Eta*(Ca*Vp.^2 + Mass*g*f);
    U0 = Radius/Eta*(Ca*X0(2).^2 + Mass*g*f);
    
    Cost = (X0(1:2)-Xdes(1,:))*Q*(X0(1:2)-Xdes(1,:))' + ...
                (u(1)-U0)*R*(u(1)-U0) + (X0(1:2)-Xa(1,:))*F*(X0(1:2)-Xa(1,:))'+ ...
                (X0(1:2)-Xnfa(1,:))*G*(X0(1:2)-Xnfa(1,:))'+(X0(1:2)-Xnffa(1,:))*G*(X0(1:2)-Xnffa(1,:))'+ (X0(3)*X0(2)/v)*W*(X0(3)*X0(2)/v)';                               % ��һ�����Ż�ֵ
    for i = 1:Np-1        %% ע�ⷶ���Ķ������⣬ X'Q'QX
        Cost = Cost + (Xp(i,:)-Xdes(i+1,:))*Q*(Xp(i,:)-Xdes(i+1,:))' + ...
                (u(i+1)-Udes(i))*R*(u(i+1)-Udes(i)) + (Xp(i,:)-Xa(i+1,:))*F*(Xp(i,:)-Xa(i+1,:))'+ ...
                (Xp(i,:)-Xnfa(i+1,:))*G*(Xp(i,:)-Xnfa(i+1,:))'+(X0(1:2)-Xnffa(1,:))*G*(X0(1:2)-Xnffa(1,:))'+ (Tp(i)*Vp(i)/v)*W*(Tp(i)*Vp(i)/v)';               
    end
   
end

