function zs = BSFC1(pe)
       p1 =   6.196e-18  ;
       p2 =  -1.568e-12 ;
       p3 =   1.299e-07 ;
       p4 =   0.0002723  ;
       p5 =       109.7 ;
    x = pe;   
    zs = p1*x.^4 + p2*x.^3 + p3*x.^2 + p4*x + p5;
    
end