function Nm = BSFC(rpm)
       p1 =    -8.9e-12;
       p2 =   1.558e-08;
       p3 =  -1.107e-05;
       p4 =    0.004079;
       p5 =     -0.8234;
       p6 =       86.69;
       p7 =       -3594;
    
    % Convert from W to kW
    x = rpm;  % *0.1047;
    Nm = p1*x.^6 + p2*x.^5 + p3*x.^4 + p4*x.^3 + p5*x.^2 + p6*x + p7
    
end